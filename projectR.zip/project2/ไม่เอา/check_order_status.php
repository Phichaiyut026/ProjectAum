<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Status</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        h2 {
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>
    <?php
    session_start();
    require_once 'database/db_pdo.php';

    // ตรวจสอบว่ามีการส่งข้อมูลแบบ POST มาหรือไม่
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // รับค่า id_product จากฟอร์ม
        $id = $_POST['id'];

        // คำสั่ง SQL เพื่อดึงข้อมูลสถานะการสั่งซื้อของสินค้า
        $stmt = $conn->prepare("SELECT * FROM production WHERE user_id = :user_id");
        $stmt->bindParam(':user_id', $id);
        $stmt->execute();

        // ตรวจสอบว่ามีข้อมูลสถานะการสั่งซื้อหรือไม่
        if ($stmt->rowCount() > 0) {
            // แสดงผลข้อมูลสถานะการสั่งซื้อ
            echo "<h2>Order Status for User ID: $id</h2>";
            echo "<table>";
            echo "<tr><th>Product Name</th><th>Quantity</th><th>Production Date</th><th>Status</th></tr>";
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr>";
                echo "<td>" . $row['product_name'] . "</td>";
                echo "<td>" . $row['quantity'] . "</td>";
                echo "<td>" . $row['production_date'] . "</td>";
                echo "<td>" . $row['status_name'] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            // ถ้าไม่พบข้อมูลสถานะการสั่งซื้อ
            echo "<h2>No order found for User ID: $id</h2>";
        }
    }
    ?>
</body>

</html> 