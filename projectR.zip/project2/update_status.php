<?php
session_start();
require_once 'database/db_pdo.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['status']) && isset($_POST['id'])) {
    $status = $_POST['status'];
    $id = $_POST['id'];

    try {
        // เตรียมคำสั่ง SQL สำหรับอัปเดตสถานะ
        $stmt = $conn->prepare("UPDATE production SET status_name = :status WHERE id = :id");
        // ผูกค่าพารามิเตอร์
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':id', $id);
        // ทำการ execute คำสั่ง SQL
        $stmt->execute();
        // ส่งข้อความกลับไปยังเว็บบราวเซอร์
        echo "Status updated successfully.";
    } catch (PDOException $e) {
        // ส่งข้อความผิดพลาดกลับไปยังเว็บบราวเซอร์
        echo "Error updating status: " . $e->getMessage();
    }
} else {
    // ส่งข้อความผิดพลาดกลับไปยังเว็บบราวเซอร์
    echo "Invalid request.";
}
?>
