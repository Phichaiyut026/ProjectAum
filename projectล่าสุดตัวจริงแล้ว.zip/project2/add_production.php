<?php
session_start();
require_once 'database/db_pdo.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // ตรวจสอบว่ามีการส่งข้อมูลมาจากฟอร์มหรือไม่
    if (isset($_POST['product_name']) && isset($_POST['details']) && isset($_POST['tellnumber']) && isset($_POST['address'])) {
        // ดึงค่าจากฟอร์ม
        $product_name = $_POST['product_name'];
        $details = $_POST['details'];
        $tellnumber = $_POST['tellnumber'];
        $address = $_POST['address'];

        try {
            // เตรียมคำสั่ง SQL สำหรับแทรกข้อมูล
            $stmt = $conn->prepare("INSERT INTO production (product_name, details, tellnumber, address) VALUES (:product_name, :details, :tellnumber, :address)");
            // ผูกค่าพารามิเตอร์
            $stmt->bindParam(':product_name', $product_name);
            $stmt->bindParam(':details', $details);
            $stmt->bindParam(':tellnumber', $tellnumber);
            $stmt->bindParam(':address', $address);
            // ทำการ execute คำสั่ง SQL
            $stmt->execute();
            // ส่งกลับไปยังหน้าหลักหลังจากที่แทรกข้อมูลเสร็จสิ้น
            header('location: index.php');
        } catch (PDOException $e) {
            // หากเกิดข้อผิดพลาดในการแทรกข้อมูล แสดงข้อความผิดพลาด
            echo "Error: " . $e->getMessage();
        }
    } else {
        // หากมีข้อมูลไม่ครบถ้วน แสดงข้อความแจ้งเตือน
        echo "กรุณากรอกข้อมูลให้ครบถ้วน";
    }
}
