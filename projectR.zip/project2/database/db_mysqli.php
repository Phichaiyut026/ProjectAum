<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

// Create connection
$conn_mysqli = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn_mysqli->connect_error) {
    die("Connection failed (MySQLi): " . $conn_mysqli->connect_error);
}
?>
