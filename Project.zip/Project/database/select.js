var mysql = require('mysql');
var conn = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '143826',
    database: 'project'
});

conn.connect();

var sqlStr = "select user_id, user_name, email, password from admin";
conn.query(sqlStr, function (err, result) {
    if (err) {
        console.log(err);
        conn.end();
        return;
    }
    console.log(result);
    conn.end();
});
