<?php include 'head.php'; ?>
<?php
session_start();
require_once 'database/db_pdo.php';
// if (!isset($_SESSION['admin_login'])) {
//     $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
//     header('location: login.php');
// }
$stmt = $conn->query("SELECT * FROM production");
?>

<body>
  <div class="container mt-5">
    <div class="card">
      <div class="card-header">
        <h3>ประวัติการสั่งผลิต</h3>
      </div>
      <div class="card-body">
        <table id="dataTable" class="table table-bordered table-hover">
          <thead>
            <tr>
              <th>Product Name</th>
              <th>Quantity</th>
              <th>Production Date</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
              echo "<tr>";
              echo "<td>" . $row['product_name'] . "</td>";
              echo "<td>" . $row['quantity'] . "</td>";
              echo "<td>" . $row['production_date'] . "</td>";
              echo "<td>" . $row['status_name'] . "</td>";
              echo "<td><a href='view_production.php?id=" . $row['id'] . "' class='btn btn-info'>View</a></td>";
              echo "</tr>";
            }
            ?>
          </tbody>
        </table>
        <a href="index.php" class="btn btn-info">กลับหน้าหลัก</a>
      </div>
    </div>
  </div>

</body>

</html>