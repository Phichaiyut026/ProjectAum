<!DOCTYPE html>
<html lang="en">

<head>
    <title>CMT lab</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Rubik:400,700" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/rangeslider.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/jquery-migrate-3.0.1.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/bootstrap-datepicker.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/rangeslider.min.js"></script>
    <script src="js/typed.js"></script>
</head>
<style>
    .menu-item {
        font-size: 18px;
    }
    .menu-item:hover {
        background-color: green;
    }
    .site-blocks-cover{
        height: 200px;
    }
</style>

<body>
    <?php
    if (isset($_SESSION['user_login'])) {
        $user_id = $_SESSION['user_login'];
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = :user_id");
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    if (isset($_SESSION['admin_login'])) {
        $admin_id = $_SESSION['admin_login'];
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = :admin_id");
        $stmt->bindParam(':admin_id', $admin_id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    ?>
    <div class="site-wrap">
        <div class="site-mobile-menu">
            <div class="site-mobile-menu-header">
                <div class="site-mobile-menu-close mt-3">
                    <span class="icon-close2 js-menu-toggle"></span>
                </div>
            </div>
            <div class="site-mobile-menu-body"></div>
        </div>
        <header class="site-navbar" role="banner">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-11 col-xl-4">
                    </div>
                    <div class="col-12 col-md-8 d-none d-xl-block">
                        <nav class="site-navigation position-relative text-right" role="navigation">
                            <ul class="site-menu js-clone-nav mr-auto d-none d-lg-block">
                                <li <?php if (basename($_SERVER['PHP_SELF']) == 'index.php') echo 'class="active"'; ?>><a href="index.php"><span class="menu-item">Home</span></a></li>
                                <li <?php if (basename($_SERVER['PHP_SELF']) == 'feed.php') echo 'class="active"'; ?>><a href="feed.php"><span class="menu-item">ข่าวสาร</span></a></li>
                                <?php if (!isset($_SESSION['user_login']) && !isset($_SESSION['admin_login'])) : ?>
                                    <li class="has-children">
                                        <a href="#">services</a>
                                        <ul class="dropdown">
                                            <li><a href="login.php"><span>login</span></a></li>
                                            <li><a href="register.php"><span>Register</span></a></li>
                                        </ul>
                                    </li>
                                <?php endif; ?>
                                <?php if (isset($_SESSION['user_login']) || isset($_SESSION['admin_login'])) : ?>
                                    <li class="has-children">
                                        <a href=""><span><?php echo $row['firstname'] . ' ' . $row['lastname']; ?></span></a>
                                        <ul class="dropdown arrow-top">
                                            <li><a href="status.php">เช็คสถานะสั่งผลิต</a></li>
                                            <li><a class="dropdown-item" href="from_production.php">สั่งสินค้า</a></li>
                                            <?php if (isset($_SESSION['admin_login'])) : ?>
                                                <li><a href="admin.php">จัดการฐานข้อมูล</a></li>
                                            <?php endif; ?>
                                            <li><a href="logout.php">ออกจากระบบ</a></li>
                                        </ul>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                    <div class="d-inline-block d-xl-none ml-md-0 mr-auto py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle text-white"><span class="icon-menu h3"></span></a></div>
                </div>
            </div>
    </div>
    </header>
    <div class="site-blocks-cover overlay" style="background-image: url(images/bg.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
        <!-- <div class="container">
            <div class="row align-items-center justify-content-center text-center">

                <div class="col-md-10">
                    <div class="row justify-content-center mb-4">
                        <div class="col-md-10 text-center">
                            <h1 data-aos="fade-up" class="mb-5">Get <span class="typed-words"></span></h1>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
    </div>