<?php include 'head.php'; ?>
<?php
session_start();
require_once 'database/db_pdo.php';
// if (!isset($_SESSION['admin_login'])) {
//     $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
//     header('location: login.php');
// }
?>
<?php
//ไฟล์เชื่อมต่อฐานข้อมูล
//คิวรี่ข้อมูลมาแสดงใน select option
$stmt = $conn->prepare("SELECT* FROM production");
$stmt->execute();
$rs = $stmt->fetchAll();
?>
<?php
//ไฟล์เชื่อมต่อฐานข้อมูล
//คิวรี่ข้อมูลมาแสดงใน select option
$stmt = $conn->prepare("SELECT* FROM product");
$stmt->execute();
$rs = $stmt->fetchAll();
?>
<style>
    body {
        background-color: #f8f9fa;
        font-family: Arial, sans-serif;
    }

    .container {
        max-width: 500px;
        margin: 50px auto;
        background-color: #fff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
        text-align: center;
        margin-bottom: 30px;
    }

    label {
        font-weight: bold;
    }

    .form-control {
        border-radius: 5px;
    }

    button[type="submit"],
    a.btn {
        margin-top: 20px;
        width: 100%;
    }
</style>

<body>
    <div class="container">
        <h1>สั่งผลิตสินค้า</h1>
        <form action="add_production.php" method="post">
            <!-- <div class="mb-3">
                <label for="product_name" class="form-label">ชื่อสินค้า</label>
                <select class="form-control" id="product_name" name="product_name" required>
                <option value="">เลือกสินค้า</option>
                    <option>Body Lotion Booster</option>
                    <option>Cream Face</option>
                    <option>Baby Serum Booter</option>
                    <option>Baby Lotion Booster</option>
                </select>
            </div> -->
            <div class="mb-3">
                <label for="product_name" class="form-label">ชื่อสินค้า</label>
                <?php
                if (isset($_GET['product_id'])) {
                    $product_id = $_GET['product_id'];
                    // เตรียมคำสั่ง SQL สำหรับดึงข้อมูลสินค้าจากฐานข้อมูล
                    $stmt = $conn->prepare("SELECT * FROM product WHERE id = :product_id");
                    // ผูกค่าพารามิเตอร์
                    $stmt->bindParam(':product_id', $product_id);
                    // ทำการ execute คำสั่ง SQL
                    $stmt->execute();
                    // ดึงข้อมูลสินค้า
                    $row = $stmt->fetch(PDO::FETCH_ASSOC);
                    // ตรวจสอบว่าพบข้อมูลหรือไม่
                    if ($row) {
                        // แสดงชื่อสินค้าใน input
                        echo "<input type='text' class='form-control' id='product_name' name='product_name' value='" . $row['product_name'] . "' readonly required>";
                    } else {
                        // ถ้าไม่พบข้อมูลสินค้าให้แสดงข้อความว่า "ไม่พบข้อมูลสินค้า"
                        echo "<input type='text' class='form-control' id='product_name' name='product_name' value='ไม่พบข้อมูลสินค้า' readonly required>";
                    }
                }
                ?>

            </div>

            <div class="mb-3">
                <label for="quantity" class="form-label">ปริมาณ/กรัม</label>
                <select class="form-control" id="quantity" name="quantity" required>
                    <option value="">ปริมาณ</option>
                    <option>250 กรัม</option>
                    <option>300 กรัม</option>
                    <option>350 กรัม</option>
                    <option>400 กรัม</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="tellnumber" class="form-label">เบอร์โทรศัพท์</label>
                <input type="text" class="form-control" id="tellnumber" name="tellnumber" required>
            </div>
            <div class="mb-3">
                <label for="address" class="form-label">ที่อยู่</label>
                <input type="text" class="form-control" id="address" name="address" required>
            </div>
            <div class="mb-3">
                <label for="production_date" class="form-label">วันที่สั่งผลิต</label>
                <input type="date" class="form-control" id="production_date" name="production_date" required>
            </div>
            <button type="submit" class="btn btn-primary" onclick="showAlert()">สั่งผลิต</button>
            <a href="index.php" class="btn btn-primary">ย้อนกลับ</a>
        </form>
    </div>


</body>
<script>
    // เพิ่มฟังก์ชันสำหรับกำหนดค่าในช่องข้อมูลชื่อสินค้า
    function setProductionName(product_name) {
        document.getElementById("product_name").value = product_name;
    }

    function showAlert() {
        alert("ยืนยันการสั่งผลิต");
    }
</script>

</html>