<?php include 'head.php'; ?>
<?php
session_start();
require_once 'database/db_pdo.php';
// if (!isset($_SESSION['admin_login'])) {
//     $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
//     header('location: login.php');
// }
?>
<?php
//ไฟล์เชื่อมต่อฐานข้อมูล
//คิวรี่ข้อมูลมาแสดงใน select option
$stmt = $conn->prepare("SELECT* FROM product");
$stmt->execute();
$rs = $stmt->fetchAll();
?>
<body id="page-top">
    <div id="wrapper">
        <?php include 'nav.php'; ?>
        <!-- Begin Page Content -->
        <div class="container-fluid">
            <!-- Page Heading -->
            <h1 class="card-title">Add Product</h1>
            <!-- Product Form -->
            <div class="card shadow mb-4">
                <div class="card-body">
                    <form action="add_product.php" method="post">
                        <!-- <div class="mb-3">
                                <label for="product_name" class="form-label">Product Name</label>
                                <input type="text" class="form-control" id="product_name" name="product_name">
                        </div> -->
                        <div class="mb-3">
                        <label for="product_name" class="form-label">Product Name</label>
                                <select name="product_name" id="product_name" class="form-control" required>
                                    <option value="">เลือกสินค้า</option>
                                    <?php foreach ($rs as $row) { ?>
                                        <option value="<?= $row['id']; ?>">-<?= $row['product_name']; ?></option>
                                    <?php } ?>
                                </select>
                        </div>
                        <!-- <div class="d-grid gap-2 col-sm-9 mb-3">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div> -->
                        <div class="mb-3">
                            <label for="quantity" class="form-label">Quantity</label>
                            <input type="number" class="form-control" id="quantity" name="quantity">
                        </div>
                        <div class="mb-3">
                            <label for="details" class="form-label">Details</label>
                            <textarea class="form-control" id="details" name="details" rows="3"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Add Product</button>
                    </form>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->

    <!-- Footer -->
    <footer class="sticky-footer bg-white">
        <div class="container my-auto">
            <div class="copyright text-center my-auto">
                <span>Copyright &copy; Your Website 2020</span>
            </div>
        </div>
    </footer>
    <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

    </div>
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="//cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="js/demo/datatables-demo.js"></script>

</body>

</html>