<?php
session_start();
require_once 'database/db_pdo.php';
// if (!isset($_SESSION['user_login'])) {
//     $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
//     header('location: login.php');
// }
?>
<?php include 'head.php'; ?>
<?php include 'navbar.php'; ?>
<?php include 'product.php'; ?>
