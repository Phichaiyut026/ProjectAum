<?php
session_start();
require_once 'database/db_pdo.php';
// if (!isset($_SESSION['admin_login'])) {
//     $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
//     header('location: login.php');
// }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>CMT lab</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Rubik:400,700" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/rangeslider.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <?php
    if (isset($_SESSION['user_login'])) {
        $user_id = $_SESSION['user_login'];
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = :user_id");
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    if (isset($_SESSION['admin_login'])) {
        $admin_id = $_SESSION['admin_login'];
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = :admin_id");
        $stmt->bindParam(':admin_id', $admin_id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    ?>
    <div class="site-wrap">
        <div class="site-mobile-menu">
            <div class="site-mobile-menu-header">
                <div class="site-mobile-menu-close mt-3">
                    <span class="icon-close2 js-menu-toggle"></span>
                </div>
            </div>
            <div class="site-mobile-menu-body"></div>
        </div>
        <header class="site-navbar" role="banner">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-11 col-xl-4">
                    </div>
                    <div class="col-12 col-md-8 d-none d-xl-block">
                        <nav class="site-navigation position-relative text-right" role="navigation">
                            <ul class="site-menu js-clone-nav mr-auto d-none d-lg-block">
                                <li class="active"><a href="index.php"><span>Home</span></a></li>
                                <li><a href="about.html"><span>About</span></a></li>
                                <li><a href="feed.php"><span>ข่าวสาร</span></a></li>
                                <?php if (!isset($_SESSION['user_login']) && !isset($_SESSION['admin_login'])) : ?>
                                    <li class="has-children">
                                        <a href="#">services</a>
                                        <ul class="dropdown">
                                            <li><a href="login.php"><span>login</span></a></li>
                                            <li><a href="register.php"><span>Register</span></a></li>
                                        </ul>
                                    </li>
                                <?php endif; ?>
                                <?php if (isset($_SESSION['user_login']) || isset($_SESSION['admin_login'])) : ?>
                                    <li class="has-children">
                                        <a href=""><span><?php echo $row['firstname'] . ' ' . $row['lastname']; ?></span></a>
                                        <ul class="dropdown arrow-top">
                                            <li><a href="#">Profile</a></li>
                                            <li><a href="status.php">เช็คสถานะสั่งผลิต</a></li>
                                            <?php if (isset($_SESSION['admin_login'])) : ?>
                                                <!-- <li class="has-children">
                                                    <a href="#">Dropdown</a>
                                                    <ul class="dropdown">
                                                        <li><a href="admin.php">for admin</a></li>
                                                    </ul>
                                                </li> -->
                                                <li><a href="admin.php">จัดการฐานข้อมูล</a></li>
                                            <?php endif; ?>
                                            <li><a href="logout.php">ออกจากระบบ</a></li>
                                        </ul>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                    <div class="d-inline-block d-xl-none ml-md-0 mr-auto py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle text-white"><span class="icon-menu h3"></span></a></div>
                </div>
            </div>
    </div>
    </header>
    <div class="site-blocks-cover overlay" style="background-image: url(images/bg.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
        <div class="container">
            <div class="row align-items-center justify-content-center text-center">

                <!-- <div class="col-md-10">

                    <div class="row justify-content-center mb-4">
                        <div class="col-md-10 text-center">
                            <h1 data-aos="fade-up" class="mb-5">We give solutions to your <span class="typed-words"></span></h1>

                            <p data-aos="fade-up" data-aos-delay="100"><a href="#" class="btn btn-primary btn-pill">Get Started</a></p>
                        </div>
                    </div>

                </div> -->
            </div>
        </div>
    </div>
    <div class="block-quick-info-2">
        <div class="container">
            <div class="block-quick-info-2-inner">
                <div class="row">
                    <div class="col-sm-6 col-md-6 col-lg-3 mb-3 mb-lg-0">
                        <div class="d-flex quick-info-2">
                            <span class="icon icon-home mr-3"></span>
                            <div class="text">
                                <strong class="d-block heading">ที่อยู่บริษัท</strong>
                                <span class="excerpt">99/222 หมู่ 5
                                    ต.เหมือง อ.เมืองชลบุรี จ.ชลบุรี 20130</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-2 mb-3 mb-lg-0">
                        <div class="d-flex quick-info-2">
                            <span class="icon icon-phone mr-3"></span>
                            <div class="text">
                                <strong class="d-block heading">Line ID</strong>
                                <span class="excerpt"><a href="#">oem.cosmet</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-4 mb-3 mb-lg-0">
                        <div class="d-flex quick-info-2">
                            <span class="icon icon-envelope mr-3"></span>
                            <div class="text">
                                <strong class="d-block heading">Email สำหรับติดต่อ</strong>
                                <span class="excerpt"><a href="#">oem.cosmeticlab@hotmail.com</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-3 mb-3 mb-lg-0">
                        <div class="d-flex quick-info-2">
                            <span class="icon icon-clock-o mr-3"></span>
                            <div class="text">
                                <strong class="d-block heading">ช่วงเวลาเปิด</strong>
                                <span class="excerpt">จันทร์-ศุกร์ 10:30 - 17:30</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="block-services-1 py-5">
        <div class="container">
            <div class="row">
                <?php
                $stmt = $conn->query("SELECT * FROM product");
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<div class='col-sm-4 mb-4'>";
                    echo "<div class='card'>";
                    echo "<img src='" . $row['file_name'] . "' class='card-img-top' alt='Card image cap'>";
                    echo "<div class='card-body'>";
                    echo "<h5 class='card-title'>" . $row['product_name'] . "</h5>";
                    echo "<p class='card-text'>" . $row['details'] . "</p>";
                    echo "<p><a href='https://www.facebook.com/cosmetic.laboratorys' class='d-inline-flex align-items-center block-service-1-more'><span>ติดต่อเพจ facebook</span> <span class='icon-keyboard_arrow_right icon'></span></a></p>";
                    echo "</div>";
                    echo "</div>";
                    echo "</div>";
                }
                ?>
            </div>
        </div>
    </div>
    <div class="mt-5 block-cta-1 primary-overlay" style="background-image: url('images/hero_bg_2.jpg')">
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="col-lg-7 mb-4 mb-lg-0">
                    <h2 class="mb-3 mt-0 text-white">Upto 30% Discount for The First Commers</h2>
                    <p class="mb-0 text-white lead">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                </div>
                <div class="col-lg-4">
                    <p class="mb-0"><a href="contact.html" class="btn btn-outline-white text-white btn-md btn-pill px-5 font-weight-bold btn-block">Contact Us</a></p>
                </div>
            </div>
        </div>
    </div>

    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-lg-0 col-lg-3">
                            <h2 class="footer-heading mb-4">Quick Links</h2>
                            <ul class="list-unstyled">
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Services</a></li>
                                <li><a href="#">Testimonials</a></li>
                                <li><a href="#">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-6 mb-5 mb-lg-0 col-lg-3">
                            <h2 class="footer-heading mb-4">Products</h2>
                            <ul class="list-unstyled">
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Services</a></li>
                                <li><a href="#">Testimonials</a></li>
                                <li><a href="#">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-6 mb-5 mb-lg-0 col-lg-3">
                            <h2 class="footer-heading mb-4">Features</h2>
                            <ul class="list-unstyled">
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Services</a></li>
                                <li><a href="#">Testimonials</a></li>
                                <li><a href="#">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-6 mb-5 mb-lg-0 col-lg-3">
                            <h2 class="footer-heading mb-4">Follow Us</h2>
                            <a href="https://www.facebook.com/cosmetic.laboratorys" class="pl-0 pr-3"><span class="icon-facebook"></span></a>
                            <a href="#" class="pl-3 pr-3"><span class="icon-twitter"></span></a>
                            <a href="#" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
                            <a href="#" class="pl-3 pr-3"><span class="icon-linkedin"></span></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <h2 class="footer-heading mb-4">Subscribe Newsletter</h2>
                    <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                    <form action="#" method="post" class="subscription">
                        <div class="input-group mb-3  d-flex align-items-stretch">
                            <input type="text" class="form-control bg-transparent" placeholder="Enter Email" aria-label="Enter Email" aria-describedby="button-addon2">
                            <button class="btn btn-primary text-white" type="button" id="button-addon2">Send</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </footer>
    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/jquery-migrate-3.0.1.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>

    <script src="js/bootstrap-datepicker.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/rangeslider.min.js"></script>


    <script src="js/typed.js"></script>
    <script>
        var typed = new Typed('.typed-words', {
            strings: ["pain", " stress", " fatigue"],
            typeSpeed: 80,
            backSpeed: 80,
            backDelay: 4000,
            startDelay: 1000,
            loop: true,
            showCursor: true
        });
    </script>
    <script src="js/main.js"></script>
</body>

</html>