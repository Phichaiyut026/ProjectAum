<?php
session_start();
require_once 'database/db_pdo.php';

if (!isset($_SESSION['admin_login'])) {
    $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
    header('location: login.php');
    exit(); // ออกจากการทำงานหลังจาก redirect
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['id']) || empty($_POST['id'])) {
        $_SESSION['error'] = 'ไม่พบข่าวที่ต้องการแก้ไข!';
        header('location: news_tb.php');
        exit(); // ออกจากการทำงานหลังจาก redirect
    }

    $id = $_POST['id'];
    $content = $_POST['content'];

    // การอัปเดตข้อมูลข่าว
    $stmt = $conn->prepare("UPDATE news SET content = :content WHERE id = :id");
    $stmt->bindParam(':content', $content);
    $stmt->bindParam(':id', $id);

    if ($stmt->execute()) {
        $_SESSION['success'] = 'อัปเดตข่าวเรียบร้อยแล้ว!';
        header('location: news_tb.php');
        exit(); // ออกจากการทำงานหลังจาก redirect
    } else {
        $_SESSION['error'] = 'มีข้อผิดพลาดเกิดขึ้นในการอัปเดตข่าว!';
        header('location: edit_news.php?id=' . $id);
        exit(); // ออกจากการทำงานหลังจาก redirect
    }
} else {
    $_SESSION['error'] = 'ไม่สามารถเข้าถึงหน้านี้โดยตรงได้!';
    header('location: news_tb.php');
    exit(); // ออกจากการทำงานหลังจาก redirect
}
?>
