var mysql=require('mysql');
var conn = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '143826',
    database: 'project'
});
conn.connect();
module.exports.conn=conn;

