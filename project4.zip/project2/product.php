<?php
session_start();
require_once 'database/db_pdo.php';

// ดึงข้อมูลจากฐานข้อมูล
$stmt = $conn->query("SELECT * FROM product");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<style>
    .card {
        margin: 20px 10px 30px 10px;
    }

    @media (max-width: 768px) {
        .card {
            margin: 10px;
        }
    }
</style>
<script>
    // ฟังก์ชันเพื่อกำหนดค่าในช่องข้อมูลชื่อสินค้าเมื่อคลิกที่ปุ่ม "สั่งผลิต"
    function setProductionName(product_name) {
        // กำหนดค่าในช่องข้อมูลชื่อสินค้าเป็นชื่อสินค้าที่เลือก
        document.getElementById("production_name").value = product_name;
    }
</script>

<body>
    <div class="container mt-5">
        <div class="row">
            <?php
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<div class='col-sm-4'>";
                echo "<div class='card'>";
                echo "<img src='image.jpg' class='card-img-top' alt='Card image cap'>";
                echo "<div class='card-body'>";
                echo "<h5 class='card-title'>" . $row['product_name'] . "</h5>";
                echo "<p class='card-text'>" . $row['description'] . "</p>";
                // เพิ่มเหตุการณ์ onclick เพื่อเรียกใช้ฟังก์ชันที่จะกำหนดค่าในช่องข้อมูลชื่อสินค้า
                echo "<a href='#' class='btn btn-primary' onclick='setProductionName(\"" . $row['product_name'] . "\")'>สั่งผลิต</a>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
            }
            ?>
        </div>
    </div>

</body>

</html>