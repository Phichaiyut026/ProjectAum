<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check Order Status</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 30px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .fm {
            margin: 0 auto;
            max-width: 900px;
            padding: 20px;
            background-color: #f4f4f4;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            width: 100%;
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>
    <h1>สถานะของสินค้า</h1>
    <div class="fm">
        <form action="status.php" method="POST">
            <label for="id">ใส่หมายเลขโทรศัพท์:</label>
            <input type="text" id="id" name="id" required>
            <button type="submit">เช็คสถานะ </button>
        </form><br>

        <?php
        session_start();
        require_once 'database/db_pdo.php';

        // ตรวจสอบว่ามีการส่งข้อมูลแบบ POST มาหรือไม่
        // ตรวจสอบว่ามีการส่งข้อมูลแบบ POST มาหรือไม่
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // รับค่า tellnumber จากฟอร์ม
            $tellnumber = $_POST['id'];

            // คำสั่ง SQL เพื่อดึงข้อมูลสถานะการสั่งซื้อของสินค้า
            $stmt = $conn->prepare("SELECT * FROM production WHERE tellnumber = :tellnumber");
            $stmt->bindParam(':tellnumber', $tellnumber);
            $stmt->execute();

            // ตรวจสอบว่ามีข้อมูลสถานะการสั่งซื้อหรือไม่
            if ($stmt->rowCount() > 0) {
                // แสดงผลข้อมูลสถานะการสั่งซื้อ
                echo "<h3>หมายเลข: $tellnumber</h3>";
                echo "<table>";
                echo "<tr><th>ชื่อสินค้า</th><th>รายละเอียด</th><th>ที่อยู่</th><th>วันที่สั่งผลิต</th><th>สถานะ</th></tr>";
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<tr>";
                    echo "<td>" . $row['product_name'] . "</td>";
                    echo "<td>" . $row['details'] . "</td>";
                    echo "<td>" . $row['production_date'] . "</td>";
                    echo "<td>" . $row['address'] . "</td>";
                    echo "<td>" . $row['status_name'] . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                // ถ้าไม่พบข้อมูลสถานะการสั่งซื้อ
                echo "<h5>ไม่พบข้อมูลสถานะการสั่งซื้อ: $tellnumber</h5>";
            }
        }
        ?><br>
        <a href="index.php" class="btn btn-success">ย้อนกลับ</a>
    </div>
</body>

</html>