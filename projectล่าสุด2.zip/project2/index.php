<?php
session_start();
require_once 'database/db_pdo.php';
// if (!isset($_SESSION['admin_login'])) {
//     $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
//     header('location: login.php');
// }

?>
<?php include 'head_index.php'; ?>

<div class="block-quick-info-2">
    <div class="container">
        <div class="block-quick-info-2-inner">
            <div class="row">
                <div class="col-sm-6 col-md-6 col-lg-3 mb-3 mb-lg-0">
                    <div class="d-flex quick-info-2">
                        <span class="icon icon-home mr-3"></span>
                        <div class="text">
                            <strong class="d-block heading">ที่อยู่บริษัท</strong>
                            <span class="excerpt">99/222 หมู่ 5
                                ต.เหมือง อ.เมืองชลบุรี จ.ชลบุรี 20130</span>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-6 col-lg-2 mb-3 mb-lg-0">
                    <div class="d-flex quick-info-2">
                        <span class="icon icon-phone mr-3"></span>
                        <div class="text">
                            <strong class="d-block heading">Line ID</strong>
                            <span class="excerpt"><a href="#">oem.cosmet</a></span>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-6 col-lg-4 mb-3 mb-lg-0">
                    <div class="d-flex quick-info-2">
                        <span class="icon icon-envelope mr-3"></span>
                        <div class="text">
                            <strong class="d-block heading">Email สำหรับติดต่อ</strong>
                            <span class="excerpt"><a href="#">oem.cosmeticlab@hotmail.com</a></span>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-6 col-lg-3 mb-3 mb-lg-0">
                    <div class="d-flex quick-info-2">
                        <span class="icon icon-clock-o mr-3"></span>
                        <div class="text">
                            <strong class="d-block heading">ช่วงเวลาเปิด</strong>
                            <span class="excerpt">จันทร์-ศุกร์ 10:30 - 17:30</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="site-section">
    <div class="container">
        <h1>ข่าวสาร</h1>
        <div class="row">
            <?php
            $stmt = $conn->query("SELECT * FROM news LIMIT 3");
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<div class='col-sm-4 mb-4'>";
                echo "<div class='card'>";
                echo "<img src='" . $row['image_url'] . "' class='card-img-top' alt='Card image cap'>";
                echo "<div class='card-body'>";
                echo "<h5 class='card-title'>" . substr($row['content'], 0, 100) . "..." . "</h5>"; // แสดงเนื้อหาข่าวสารเฉพาะส่วนหนึ่ง โดยเริ่มต้นจากตัวอักษรที่ 0 และความยาวที่แสดงคือ 100 ตัวอักษร
                echo "<p><a href='https://www.facebook.com/cosmetic.laboratorys' class='d-inline-flex align-items-center block-service-1-more'><span>ติดต่อเพจ facebook</span> <span class='icon-keyboard_arrow_right icon'></span></a></p>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
            }
            ?>

        </div>

    </div>
</div>
<div class="block-services-1 py-5">
    <div class="container">
        <h1>ผลิตภัณฑ์</h1>
        <div class="row">
            <?php
            $stmt = $conn->query("SELECT * FROM product");
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<div class='col-sm-4 mb-4'>";
                echo "<div class='card'>";
                echo "<img src='" . $row['file_name'] . "' class='card-img-top' alt='Card image cap'>";
                echo "<div class='card-body'>";
                echo "<h5 class='card-title'>" . $row['product_name'] . "</h5>";
                echo "<p class='card-text'>" . $row['details'] . "</p>";
                echo "<p><a href='https://www.facebook.com/cosmetic.laboratorys' class='d-inline-flex align-items-center block-service-1-more'><span>ติดต่อเพจ facebook</span> <span class='icon-keyboard_arrow_right icon'></span></a></p>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
            }
            ?>
        </div>
    </div>
</div>
<div class="mt-5 block-cta-1 primary-overlay" style="background-image: url('images/hero_bg_2.jpg')">
    <div class="container">
        <div class="row align-items-center justify-content-between">
            <div class="col-lg-7 mb-4 mb-lg-0">
                <h2 class="mb-3 mt-0 text-white ">Cosmetic laboratories - โรงงานผลิตทำแบรนด์สบู่ ครีม สกินแคร์ครบวงจร</h2>
                <p class="mb-0 text-white lead">รับผลิต ทำแบรนด์อย่างถูกต้อง พร้อมบริการขอเลขที่จดแจ้งครบวงจร
                    งบหลักพันสามารถเป็นเจ้าของแบรนด์ได้</p>
            </div>
            <div class="col-lg-4">
                <p class="mb-0"><a href="contact.php" class="btn btn-outline-white text-white btn-md btn-pill px-5 font-weight-bold btn-block">Contact Us</a></p>
            </div>
        </div>
    </div>
</div>
<?php include 'footer_index.php'; ?>
<script>
    var typed = new Typed('.typed-words', {
        strings: ["อยากมีแบรนด์เป็นของตัวเอง"],
        typeSpeed: 80,
        backSpeed: 80,
        backDelay: 4000,
        startDelay: 1000,
        loop: true,
        showCursor: true
    });
</script>
<script src="js/main.js"></script>
</body>

</html>