<?php
session_start();
require_once 'database/db_pdo.php';

$stmt = $conn->query("SELECT * FROM product");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .card {
            margin: 20px 10px 30px 10px;
        }

        @media (max-width: 768px) {
            .card {
                margin: 10px;
            }
        }
    </style>
</head>

<body>

    <div class="container mt-5">
        <div class="row">
            <?php
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<div class='col-sm-4'>";
                echo "<div class='card'>";
                echo "<img src='" . $row['images'] . "' class='card-img-top' alt='Card image cap'>";
                echo "<div class='card-body'>";
                echo "<h5 class='card-title'>" . $row['product_name'] . "</h5>";
                echo "<p class='card-text'>" . $row['description'] . "</p>";
                echo "<a href='from_production.php?product_id=" . $row['id'] . "' class='btn btn-primary'>สั่งผลิต</a>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
            }
            ?>
        </div>
    </div>
    
</body>

</html>
