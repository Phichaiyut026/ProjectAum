<?php
session_start();
require_once 'database/db_pdo.php';
// if (!isset($_SESSION['admin_login'])) {
//     $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
//     header('location: login.php');
// }

?>
<?php include 'head_index.php'; ?>
<div class="site-section">
    <div class="container">
        <center>
            <h1 data-aos="fade-up" class="mb-5"><span class="typed-words"></span></h1>
        </center>
        <div class="row">
            <?php
            if (isset($_GET['news_id'])) {
                $news_id = $_GET['news_id'];
                $stmt_news = $conn->prepare("SELECT * FROM news WHERE id = :news_id");
                $stmt_news->bindParam(':news_id', $news_id);
                $stmt_news->execute();
                $news_row = $stmt_news->fetch(PDO::FETCH_ASSOC);
                if ($news_row) {
                    echo "<div class='col-md-6 mx-auto'>";
                    echo "<div class='card-body'>";
                    echo "<img src='" . $news_row['image_url'] . "' class='card-img-top' alt='News Image'>";
                    echo "<h5 class='card-title'>" . $news_row['content'] . "</h5>";
                    echo "<p class='card-text'>Published on: " . $news_row['publish_date'] . "</p>"; // เพิ่มส่วนของ publish_date
                    echo "</div>";
                    echo "</div>";
                } else {
                    echo "<div class='col-md-6 mx-auto'>";
                    echo "<div class='card-body'>";
                    echo "<h5 class='card-title'>ไม่พบข้อมูลข่าว</h5>";
                    echo "</div>";
                    echo "</div>";
                }
            }
            ?>
        </div>

    </div>
</div>
<?php include 'footer_index.php'; ?>
<script>
    var typed = new Typed('.typed-words', {
        strings: ["Post Update"],
        typeSpeed: 80,
        backSpeed: 80,
        backDelay: 4000,
        startDelay: 1000,
        loop: false,
        showCursor: true
    });
</script>

<script src="js/main.js"></script>

</body>

</html>