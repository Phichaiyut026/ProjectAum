<?php
// เชื่อมต่อกับฐานข้อมูล
require_once 'database/db_pdo.php';

// ตรวจสอบว่ามีการส่งข้อมูลแบบ POST มาหรือไม่
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // รับข้อมูลจากฟอร์ม
    $title = $_POST['title'];
    
    // ตรวจสอบว่าไฟล์รูปภาพถูกอัปโหลดหรือไม่
    if(isset($_FILES['image'])) {
        // ตั้งค่าตำแหน่งและชื่อไฟล์ภาพ
        $target_dir = "images/";
        $target_file = $target_dir . basename($_FILES["image"]["name"]);

        // บันทึกข้อมูลลงในฐานข้อมูล
        $stmt = $conn->prepare("INSERT INTO product (file_name) VALUES (:file_name)");
        $stmt->bindParam(':file_name', $target_file);
        $stmt->execute();

        // ย้ายไฟล์รูปภาพไปยังไดเรกทอรี "images"
        move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
        
        echo "The file ". htmlspecialchars( basename( $_FILES["image"]["name"])). " has been uploaded.";
    } else {
        echo "No image file uploaded.";
    }
}
?>
