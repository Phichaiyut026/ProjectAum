<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
</head>

<body>
    <div class="container mt-3">
        <h2>Edit User</h2>
        <?php
        // Include database connection
        include 'database/db_pdo.php';

        // Check if user ID is set and not empty
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            // Get user ID from URL parameter
            $user_id = $_GET['id'];

            // Prepare and execute SQL query to fetch user data by ID
            $stmt = $conn->prepare("SELECT * FROM users WHERE id = :id");
            $stmt->bindParam(':id', $user_id);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // Check if user exists
            if ($user) {
                // Display edit form with user data
        ?>
                <form action="update.php" method="POST">
                    <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                    <div class="mb-3">
                        <label for="firstname" class="form-label">Firstname</label>
                        <input type="text" class="form-control" id="firstname" name="firstname" value="<?php echo $user['firstname']; ?>">
                    </div>
                    <div class="mb-3">
                        <label for="lastname" class="form-label">Lastname</label>
                        <input type="text" class="form-control" id="lastname" name="lastname" value="<?php echo $user['lastname']; ?>">
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo $user['email']; ?>">
                    </div>
                    <div class="mb-3">
                        <label for="urole" class="form-label">User Role</label>
                        <input type="text" class="form-control" id="urole" name="urole" value="<?php echo $user['urole']; ?>">
                    </div>

                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </form>
        <?php
            } else {
                // Display error message if user does not exist
                echo '<div class="alert alert-danger" role="alert">User not found!</div>';
            }
        } else {
            // Display error message if user ID is not provided
            echo '<div class="alert alert-danger" role="alert">User ID is missing!</div>';
        }
        ?>
    </div>
</body>

</html>