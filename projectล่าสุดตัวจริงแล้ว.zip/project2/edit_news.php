<?php
session_start();
require_once 'database/db_pdo.php';
if (!isset($_SESSION['admin_login'])) {
    $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
    header('location: login.php');
    exit(); // ออกจากการทำงานหลังจาก redirect
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = 'ไม่พบข่าวที่ต้องการแก้ไข!';
    header('location: news_tb.php');
    exit(); // ออกจากการทำงานหลังจาก redirect
}

$id = $_GET['id'];

// ดึงข้อมูลข่าวจากฐานข้อมูล
$stmt = $conn->prepare("SELECT * FROM news WHERE id = ?");
$stmt->execute([$id]);
$news = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$news) {
    $_SESSION['error'] = 'ไม่พบข่าวที่ต้องการแก้ไข!';
    header('location: news_tb.php');
    exit(); // ออกจากการทำงานหลังจาก redirect
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit News</title>
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>

<body id="page-top">
    <div id="wrapper">
        <?php include 'nav.php'; ?>
        <div class="container-fluid">
            <div class="card shadow mb-4">
                <div class="card-body">
                    <h2 class="text-center mb-4">Edit News</h2>
                    <!-- Form for editing news -->
                    <form action="update_news.php" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?php echo $news['id']; ?>">
                        <div class="mb-3">
                            <label for="image" class="form-label">Image</label>
                            <img src="<?php echo $news['image_url']; ?>" alt="News Image" class="img-fluid">
                            <label for="image" class="form-label mt-2">Update Image (Optional)</label>
                            <input type="file" class="form-control" id="image" name="image">
                        </div>
                        <div class="mb-3">
                            <label for="content" class="form-label">Content</label>
                            <textarea class="form-control" id="content" name="content" rows="3" required><?php echo $news['content']; ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Update News</button>
                        <a href="news_tb.php" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>
        </div>

    </div>
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="//cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="js/demo/datatables-demo.js"></script>

</body>

</html>
