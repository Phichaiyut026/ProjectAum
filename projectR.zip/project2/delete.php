<?php
// รับค่าไอดีของผู้ใช้ที่ต้องการลบ
$user_id = $_GET['id'];

// เชื่อมต่อฐานข้อมูล
include 'database/db_pdo.php';

// สร้างคำสั่ง SQL เพื่อลบผู้ใช้
$stmt = $conn->prepare("DELETE FROM users WHERE id = :user_id");
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();

// Redirect กลับไปยังหน้า Admin หลังจากที่ทำการลบข้อมูลเสร็จสมบูรณ์
header("Location: admin.php");
exit();
?>
