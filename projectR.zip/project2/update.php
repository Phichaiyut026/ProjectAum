<?php
// Include database connection
include 'database/db_pdo.php'; 

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if all required fields are set
    if (isset($_POST['id']) && isset($_POST['firstname']) && isset($_POST['lastname']) && isset($_POST['email']) && isset($_POST['urole'])) {
        // Prepare SQL statement to update user data
        $stmt = $conn->prepare("UPDATE users SET firstname = :firstname, lastname = :lastname, email = :email, urole = :urole WHERE id = :id");
        // Bind parameters
        $stmt->bindParam(':id', $_POST['id']);
        $stmt->bindParam(':firstname', $_POST['firstname']);
        $stmt->bindParam(':lastname', $_POST['lastname']);
        $stmt->bindParam(':email', $_POST['email']);
        $stmt->bindParam(':urole', $_POST['urole']);
        // Execute the update statement
        if ($stmt->execute()) {
            // Redirect back to user table page after successful update
            header("Location: admin.php");
            exit();
        } else {
            // Display error message if update fails
            echo "Error updating user.";
        }
    } else {
        // Display error message if required fields are missing
        echo "All fields are required.";
    }
}
?>
