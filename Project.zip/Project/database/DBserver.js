var http=require('http');
var mysql = require('mysql');
var server=http.createServer();
server.on('request',function(req,res){
    res.setHeader('Access-Control-Allow-Origin','*');
    res.writeHead(200,{'Content-Type':'text/plain;charset=utf-8'});
    var conn = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: '143826',
        database: 'project'
    });
    conn.connect();

    var sqlStr = "select user_id, user_name, email, password from admin";
    conn.query(sqlStr, function (err, result) {
        if (err) {
            console.log(err);
            conn.end();
            return;
        }
        console.log(result);
        res.end(JSON.stringify(result));
    });
})
server.listen(3009,function(err){
    console.log('server is runing at localhost:3009')
})