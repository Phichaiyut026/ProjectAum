<?php
session_start();
require_once 'database/db_pdo.php';

if (!isset($_SESSION['admin_login'])) {
    $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
    header('location: login.php');
    exit(); // ออกจากการทำงานหลังจาก redirect
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id']) && !empty($_GET['id'])) {
    $id = $_GET['id'];

    // คำสั่ง SQL สำหรับลบข้อมูลข่าว
    $stmt = $conn->prepare("DELETE FROM news WHERE id = ?");
    if ($stmt->execute([$id])) {
        $_SESSION['success'] = 'ลบข่าวเรียบร้อยแล้ว!';
    } else {
        $_SESSION['error'] = 'มีข้อผิดพลาดเกิดขึ้นในการลบข่าว!';
    }
} else {
    $_SESSION['error'] = 'ไม่สามารถเข้าถึงหน้านี้โดยตรงได้!';
}

header('location: news_tb.php');
exit(); // ออกจากการทำงานหลังจาก redirect
?>
