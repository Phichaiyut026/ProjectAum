<?php include 'head.php'; ?>
<?php
session_start();
require_once 'database/db_pdo.php';
// if (!isset($_SESSION['admin_login'])) {
//     $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
//     header('location: login.php');
// }
?>
<?php
//ไฟล์เชื่อมต่อฐานข้อมูล
//คิวรี่ข้อมูลมาแสดงใน select option
$stmt = $conn->prepare("SELECT* FROM production");
$stmt->execute();
$rs = $stmt->fetchAll();
?>
<style>
    /* Add custom CSS styles here */
    body {
        padding-top: 50px;
        /* Adjust as needed */
    }

    .container {
        max-width: 600px;
        /* Adjust container width as needed */
        margin: auto;
    }

    form {
        margin-top: 20px;
    }

    /* Optional: Add more custom styles for form elements */
    .mb-3 {
        margin-bottom: 20px;
    }

    label {
        font-weight: bold;
    }

    /* Add more custom styles as needed */
</style>

<body>
    <div class="container">
        <h1>สั่งผลิตสินค้า</h1>
        <form action="add_production.php" method="post">
            <!-- <div class="mb-3">
                <label for="product_name" class="form-label">ชื่อสินค้า</label>
                <select class="form-control" id="product_name" name="product_name" required>
                <option value="">เลือกสินค้า</option>
                    <option>Body Lotion Booster</option>
                    <option>Cream Face</option>
                    <option>Baby Serum Booter</option>
                    <option>Baby Lotion Booster</option>
                </select>
            </div> -->
            <div class="mb-3">
                <label for="production_name" class="form-label">ชื่อสินค้า</label>
                <input type="text" class="form-control" id="production_name" name="production_name" readonly required>
            </div>

            <div class="mb-3">
                <label for="quantity" class="form-label">ปริมาณ/กรัม</label>
                <select class="form-control" id="quantity" name="quantity" required>
                    <option value="">ปริมาณ</option>
                    <option>250 กรัม</option>
                    <option>300 กรัม</option>
                    <option>350 กรัม</option>
                    <option>400 กรัม</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="production_date" class="form-label">วันที่สั่งผลิต</label>
                <input type="date" class="form-control" id="production_date" name="production_date" required>
            </div>
            <button type="submit" class="btn btn-primary">สั่งผลิต</button>
            <a href="index.php" class="btn btn-primary">ย้อนกลับ</a>
        </form>
    </div>
</body>


</html>