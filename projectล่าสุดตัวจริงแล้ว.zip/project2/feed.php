<?php
session_start();
require_once 'database/db_pdo.php';
// if (!isset($_SESSION['admin_login'])) {
//     $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
//     header('location: login.php');
// }

?>
<?php include 'head_index.php'; ?>
<style>

</style>
<div class="site-section">
    <div class="container">
        <center>
            <h1 data-aos="fade-up" class="mb-5"><span class="typed-words"></span></h1>
        </center>
        <div class="row">
            <?php
            $stmt = $conn->query("SELECT * FROM news");
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<div class='col-sm-4 mb-4'>";
                echo "<div class='card'>";
                echo "<img src='" . $row['image_url'] . "' class='card-img-top' alt='Card image cap'>";
                echo "<div class='card-body'>";
                echo "<h5 class='card-title'>" . substr($row['content'], 0, 100) . "..." . "</h5>";
                // ให้ลิงก์นำไปยังหน้า Learn_index.php พร้อมส่งค่า news_id ไปด้วย
                echo "<p><a href='Learn_index.php?news_id=" . $row['id'] . "' class='btn btn-primary'>Read More</a></p>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
            }
            ?>
        </div>
    </div>
</div>
<?php include 'footer_index.php'; ?>
<script>
    var typed = new Typed('.typed-words', {
        strings: ["Post Update"],
        typeSpeed: 80,
        backSpeed: 80,
        backDelay: 4000,
        startDelay: 1000,
        loop: false,
        showCursor: true
    });
</script>

<script src="js/main.js"></script>

</body>

</html>