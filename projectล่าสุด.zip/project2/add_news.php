<?php
session_start();
require_once 'database/db_pdo.php';

// ตรวจสอบว่ามีการส่งข้อมูลแบบ POST มาหรือไม่
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // รับข้อมูลจากฟอร์ม
    $content = $_POST['content'];

    // ตรวจสอบว่าไฟล์รูปภาพถูกอัปโหลดหรือไม่
    if (isset($_FILES['image'])) {
        // ตั้งค่าตำแหน่งและชื่อไฟล์ภาพ
        $target_dir = "images/";
        $target_file = $target_dir . basename($_FILES["image"]["name"]);

        // บันทึกข้อมูลลงในฐานข้อมูล
        $stmt = $conn->prepare("INSERT INTO news (image_url, content, publish_date) VALUES (:image_url, :content, NOW())");
        $stmt->bindParam(':image_url', $target_file);
        $stmt->bindParam(':content', $content);
        $stmt->execute();

        // ย้ายไฟล์รูปภาพไปยังไดเรกทอรี "images"
        move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);

        $_SESSION['success'] = 'เพิ่มข้อมูลข่าวสารเรียบร้อยแล้ว';
    } else {
        $_SESSION['error'] = 'เกิดข้อผิดพลาดในการอัปโหลดรูปภาพ';
    }

    header('Location: news_tb.php');
    exit;
}
