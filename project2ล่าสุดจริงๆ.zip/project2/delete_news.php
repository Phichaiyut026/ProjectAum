<?php
session_start();
require_once 'database/db_pdo.php';

// ตรวจสอบว่ามีการรับค่า ID ของข่าวที่ต้องการลบหรือไม่
if(isset($_GET['id'])) {
    $news_id = $_GET['id'];

    // ลบข่าวออกจากฐานข้อมูล
    $stmt = $conn->prepare("DELETE FROM news WHERE id = :id");
    $stmt->bindParam(':id', $news_id);
    if($stmt->execute()) {
        $_SESSION['success'] = 'ลบข่าวเรียบร้อยแล้ว';
    } else {
        $_SESSION['error'] = 'เกิดข้อผิดพลาดในการลบข่าว';
    }
} else {
    $_SESSION['error'] = 'ไม่พบรหัสข่าวที่ต้องการลบ';
}

// Redirect กลับไปยังหน้าที่แสดงรายการข่าว
header('Location: news_tb.php');
exit;
?>
