<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">HOME</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mynavbar">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="javascript:void(0)"></a>
                </li>
            </ul>
            <form class="d-flex">
                <li class="nav-item">
                    <div class="btn-group">
                        <?php if (!isset($_SESSION['user_login']) && !isset($_SESSION['admin_login'])) : ?>
                            <a class="btn btn-primary" href="register.php">Register</a>
                            <a class="btn btn-success"  href="login.php">Login</a>
                        <?php endif; ?>
                    </div>
                </li>
                <?php
                if (isset($_SESSION['user_login'])) {
                    $user_id = $_SESSION['user_login'];
                    $stmt = $conn->prepare("SELECT * FROM users WHERE id = :user_id");
                    $stmt->bindParam(':user_id', $user_id);
                    $stmt->execute();
                    $row = $stmt->fetch(PDO::FETCH_ASSOC);
                }

                if (isset($_SESSION['admin_login'])) {
                    $admin_id = $_SESSION['admin_login'];
                    $stmt = $conn->prepare("SELECT * FROM users WHERE id = :admin_id");
                    $stmt->bindParam(':admin_id', $admin_id);
                    $stmt->execute();
                    $row = $stmt->fetch(PDO::FETCH_ASSOC);
                }
                ?>
                <?php if (isset($_SESSION['user_login']) || isset($_SESSION['admin_login'])) : ?>
                    <div class="dropdown">
                        <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown">
                            <?php echo $row['firstname'] . ' ' . $row['lastname']; ?>
                        </button>
                        <ul class="dropdown-menu">
                            <?php if (isset($_SESSION['admin_login'])) : ?>
                                <li><a class="dropdown-item" href="admin.php">จัดการฐานข้อมูล</a></li>
                            <li><a class="dropdown-item" href="history.php">ประวัติการสั่งผลิต</a></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item" href="status.php">สถานะสินค้า</a></li>
                            <hr>
                            <li><a class="dropdown-item" href="logout.php">ออกจากระบบ</a></li>
                        </ul>
                    </div>
                <?php endif; ?>
            </form>
        </div>
    </div>
</nav>