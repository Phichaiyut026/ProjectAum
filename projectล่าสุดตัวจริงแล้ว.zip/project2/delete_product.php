<?php
session_start();
require_once 'database/db_pdo.php';

// ตรวจสอบว่ามีการรับพารามิเตอร์ ID หรือไม่
if(isset($_GET['id'])) {
    $product_id = $_GET['id'];

    // ลบข้อมูลสินค้า
    $stmt = $conn->prepare("DELETE FROM product WHERE id = :id");
    $stmt->bindParam(':id', $product_id);
    if($stmt->execute()) {
        $_SESSION['success'] = 'ลบสินค้าเรียบร้อยแล้ว';
    } else {
        $_SESSION['error'] = 'เกิดข้อผิดพลาดในการลบสินค้า';
    }
} else {
    $_SESSION['error'] = 'ไม่พบรหัสสินค้าที่ต้องการลบ';
}

// Redirect กลับไปยังหน้า product.php
header('Location: product_tb.php');
exit;
?>
