<?php
session_start();
require_once 'database/db_pdo.php';
if (!isset($_SESSION['admin_login'])) {
    $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
    header('location: login.php');
}

// ตรวจสอบว่ามีการส่งค่า id มาหรือไม่
if(isset($_GET['id'])) {
    $production_id = $_GET['id'];

    // ดึงข้อมูลการผลิตจากฐานข้อมูล
    $stmt = $conn->prepare("SELECT * FROM production WHERE id = :id");
    $stmt->bindParam(':id', $production_id);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if(!$row) {
        $_SESSION['error'] = 'ไม่พบข้อมูลการผลิตนี้';
        header('location: index.php');
    }
} else {
    $_SESSION['error'] = 'ไม่ได้ระบุรหัสการผลิต';
    header('location: index.php');
}

// ตรวจสอบการส่งค่าแบบ POST มา
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // รับค่าจากฟอร์ม
    $tellnumber = $_POST['tellnumber'];
    $quantity = $_POST['quantity'];
    $production_date = $_POST['production_date'];
    $status_name = $_POST['status'];

    // ตรวจสอบว่าข้อมูลถูกกรอกครบหรือไม่
    if (!empty($quantity) && !empty($production_date) && !empty($status_name)) {
        try {
            // เตรียมคำสั่ง SQL สำหรับอัปเดตข้อมูลการผลิต
            $stmt = $conn->prepare("UPDATE production SET tellnumber = :tellnumber, quantity = :quantity, production_date = :production_date, status_name = :status_name WHERE id = :id");
            // ผูกค่าพารามิเตอร์
            $stmt->bindParam(':tellnumber', $tellnumber);
            $stmt->bindParam(':quantity', $quantity);
            $stmt->bindParam(':production_date', $production_date);
            $stmt->bindParam(':status_name', $status_name);
            $stmt->bindParam(':id', $production_id);
            // ทำการ execute คำสั่ง SQL
            if ($stmt->execute()) {
                $_SESSION['success'] = 'อัปเดตข้อมูลการผลิตเรียบร้อยแล้ว';
                header('location: production_tb.php');
            } else {
                $_SESSION['error'] = 'เกิดข้อผิดพลาดในการอัปเดตข้อมูลการผลิต';
            }
        } catch (PDOException $e) {
            $_SESSION['error'] = 'เกิดข้อผิดพลาด: ' . $e->getMessage();
        }
    } else {
        $_SESSION['error'] = 'กรุณากรอกข้อมูลให้ครบทุกช่อง';
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Production</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            padding: 20px;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
        }

        .form-label {
            font-weight: bold;
        }

        .form-control {
            margin-bottom: 15px;
        }

        .btn-primary,
        .btn-secondary {
            width: 150px;
            margin-right: 10px;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <h1>Edit Production</h1>
        <form action="" method="post">
            <div class="mb-3">
                <label for="quantity" class="form-label">Quantity</label>
                <input type="text" class="form-control" id="quantity" name="quantity" value="<?php echo $row['quantity']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="tellnumber" class="form-label">PhoneNumber</label>
                <input type="text" class="form-control" id="tellnumber" name="tellnumber" value="<?php echo $row['tellnumber']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="production_date" class="form-label">Production Date</label>
                <input type="date" class="form-control" id="production_date" name="production_date" value="<?php echo $row['production_date']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-control" id="status" name="status" required>
                    <option value="รับออเดอร์" <?php if($row['status_name'] == 'รับออเดอร์') echo 'selected'; ?>>รับออเดอร์</option>
                    <option value="ออกแบบแพ็คเกจ" <?php if($row['status_name'] == 'ออกแบบแพ็คเกจ') echo 'selected'; ?>>ออกแบบแพ็คเกจ</option>
                    <option value="รอแพ็คเกจ" <?php if($row['status_name'] == 'รอแพ็คเกจ') echo 'selected'; ?>>รอแพ็คเกจ</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Save Changes</button>
            <a href="production_tb.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>

</html>
