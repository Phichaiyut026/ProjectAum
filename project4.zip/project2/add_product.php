<?php
session_start();
require_once 'database/db_pdo.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // รับข้อมูลจากฟอร์ม
    $product_name = $_POST['product_name'];
    $quantity = $_POST['quantity'];
    $details = $_POST['details'];

    // ตรวจสอบว่าข้อมูลถูกกรอกครบหรือไม่
    if (!empty($product_name) && !empty($quantity) && !empty($details)) {
        try {
            // เตรียมคำสั่ง SQL สำหรับ insert ข้อมูล
            $stmt = $conn->prepare("INSERT INTO product (product_name, quantity, details) VALUES (:product_name, :quantity, :details)");
            // ผูกค่าพารามิเตอร์
            $stmt->bindParam(':product_name', $product_name);
            $stmt->bindParam(':quantity', $quantity);
            $stmt->bindParam(':details', $details);
            // ทำการ execute คำสั่ง SQL
            if ($stmt->execute()) {
                $_SESSION['success'] = 'เพิ่มข้อมูลสินค้าเรียบร้อยแล้ว';
            } else {
                $_SESSION['error'] = 'เกิดข้อผิดพลาดในการเพิ่มข้อมูลสินค้า';
            }
        } catch (PDOException $e) {
            $_SESSION['error'] = 'เกิดข้อผิดพลาด: ' . $e->getMessage();
        }
    } else {
        $_SESSION['error'] = 'กรุณากรอกข้อมูลให้ครบทุกช่อง';
    }
}

// Redirect กลับไปยังหน้า product.php
header('Location: product_tb.php');
exit;
?>
