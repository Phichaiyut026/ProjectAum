<?php
session_start();
require_once 'database/db_pdo.php';
// if (!isset($_SESSION['admin_login'])) {
//     $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
//     header('location: login.php');
// }

?>
<?php include 'head_index.php'; ?>
<div class="site-section bg-light">
    <div class="container">
    <center><h1 data-aos="fade-up" class="mb-5"><span class="typed-words"></span></h1></center>
        <div class="row">
            <div class="col-md-7 mb-5" data-aos="fade">
                <div class="p-4 mb-3 bg-white">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1326.1804570411432!2d100.96303766049664!3d13.322783718333705!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x311d4b6795a3056f%3A0xb2b8c10784bdbb27!2zYmlyZGxhbmRzIExhYm9yYXRvcnkg4LmC4Lij4LiH4LiH4Liy4LiZ4Lic4Lil4Li04LiV4LiE4Lij4Li14LihIOC4quC4muC4ueC5iCDguKrguKPguYnguLLguIfguYHguJrguKPguJnguJTguYzguITguKPguLXguKEg4LiE4Lij4Lia4Lin4LiH4LiI4Lij!5e1!3m2!1sth!2sth!4v1708418937342!5m2!1sth!2sth" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
                <!-- <div class="p-4 mb-3 bg-white">
                    <h3 class="h5 text-black mb-3">More Info</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa ad iure porro mollitia architecto hic consequuntur. Distinctio nisi perferendis dolore, ipsa consectetur? Fugiat quaerat eos qui, libero neque sed nulla.</p>
                    <p><a href="#" class="btn btn-primary px-4 py-2 text-white btn-pill btn-sm">Learn More</a></p>
                </div> -->
            </div>
            <div class="col-md-5" data-aos="fade" data-aos-delay="100">
                <div class="p-4 mb-3 bg-white">
                    <p class="mb-0 font-weight-bold">ที่อยู่</p>
                    <p class="mb-4">99/222 หมู่ 5 ต.เหมือง อ.เมืองชลบุรี จ.ชลบุรี 20130</p>

                    <p class="mb-0 font-weight-bold">Phone</p>
                    <p class="mb-4"><a href="#">+1 232 3235 324</a></p>

                    <p class="mb-0 font-weight-bold">Line ID</p>
                    <p class="mb-4"><a href="#">oem.cosmet</a></p>

                    <p class="mb-0 font-weight-bold">Email Address</p>
                    <p class="mb-0"><a href="#">oem.cosmeticlab@hotmail.com</a></p>

                </div>
<!-- 
                <div class="p-4 mb-3 bg-white">
                    <h3 class="h5 text-black mb-3">More Info</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa ad iure porro mollitia architecto hic consequuntur. Distinctio nisi perferendis dolore, ipsa consectetur? Fugiat quaerat eos qui, libero neque sed nulla.</p>
                    <p><a href="#" class="btn btn-primary px-4 py-2 text-white btn-pill btn-sm">Learn More</a></p>
                </div> -->

            </div>
        </div>
    </div>
</div>
<?php include 'footer_index.php'; ?>
<script>
    var typed = new Typed('.typed-words', {
        strings: ["Contact Us"],
        typeSpeed: 80,
        backSpeed: 80,
        backDelay: 4000,
        startDelay: 1000,
        loop: false,
        showCursor: true
    });

    function myMap() {
        var mapProp = {
            center: new google.maps.LatLng(51.508742, -0.120850),
            zoom: 5,
        };
        var map = new google.maps.Map(document.getElementById("googleMap"), mapProp);
    }
</script>

<script src="js/main.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY&callback=myMap"></script>
</body>

</html>