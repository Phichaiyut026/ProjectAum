var express = require('express');
var router = express.Router();
var db = require('../db.js');
const bodyParser = require('body-parser');

/* GET home page. */
router.get('/', function (req, res, next) {
  var sqlStr = "select user_id, user_name, email, password from admin";
  db.conn.query(sqlStr, function (err, result) {
    if (err) {
      console.log(err);
      return;
    }
    console.log(result);

    var sqlStr2 = "select user_id,image,text from image";
    db.conn.query(sqlStr2, function (err, result2) {
      if (err) {
        console.log(err);
        return;
      }
      console.log(result2);
      res.render('index.ejs', { data: result, data2: result2 });
    })
  })
});

// router.get('/text', function (req, res, next) {
//   var sqlStr = "SELECT fix.user_id, fix.image, fix.text, admin.user_name, admin.email FROM fix INNER JOIN admin ON fix.user_id = admin.user_id";
//   db.conn.query(sqlStr, function (err, result) {
//     if (err) {
//       console.log(err);
//       return next(err);
//     }
//     console.log(result);
//     res.render('text.ejs', { data: result });
//   });
// });

router.get('/detail', function (req, res, next) {
  var sqlStr = "select user_id, image, text from image";
  db.conn.query(sqlStr, function (err, result) {
    if (err) {
      console.log(err);
      return;
    }
    console.log(result);
    res.render('detail.ejs', { data: result });
  });
});

router.use(bodyParser.urlencoded({ extended: true }));

router.get('/login', async (req, res) => {
  const username = req.body.username;
  const password = req.body.password;

  // ตรวจสอบข้อมูลล็อกอินในฐานข้อมูล
  try {
    const sqlStr = "SELECT * FROM admin WHERE username = user_name AND password = password";
    const result = await db.conn.query(sqlStr, [username, password]);

    if (result.length > 0) {
      res.redirect('/'); // เปลี่ยนเส้นทางไปที่หน้า Index
    } else {
      res.send('Login failed');// ล็อกอินล้มเหลว
    }
  } catch (err) {
    console.error(err);
    res.status(500).send('Internal Server Error');
    res.render('login.ejs', { data: result });
  }
});

module.exports = router;
