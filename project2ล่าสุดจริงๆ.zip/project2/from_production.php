<?php include 'head.php'; ?>
<?php
session_start();
require_once 'database/db_pdo.php';
// if (!isset($_SESSION['admin_login'])) {
//     $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
//     header('location: login.php');
// }
?>
<?php
//ไฟล์เชื่อมต่อฐานข้อมูล
//คิวรี่ข้อมูลมาแสดงใน select option
$stmt = $conn->prepare("SELECT* FROM production");
$stmt->execute();
$rs = $stmt->fetchAll();
?>
<?php
//ไฟล์เชื่อมต่อฐานข้อมูล
//คิวรี่ข้อมูลมาแสดงใน select option
$stmt = $conn->prepare("SELECT* FROM product");
$stmt->execute();
$rs = $stmt->fetchAll();
?>
<style>
    body {
        background-color: #f8f9fa;
        font-family: Arial, sans-serif;
    }

    .container {
        max-width: 500px;
        margin: 50px auto;
        background-color: #fff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
        text-align: center;
        margin-bottom: 30px;
    }

    label {
        font-weight: bold;
    }

    .form-control {
        border-radius: 5px;
    }

    button[type="submit"],
    a.btn {
        margin-top: 20px;
        width: 100%;
    }
</style>

<body>
    <div class="container">
        <h1>สั่งผลิตสินค้า</h1>
        <form action="add_production.php" method="post">
            <div class="form-group">
                <label for="product_name">ชื่อสินค้า:</label>
                <input type="text" class="form-control" id="product_name" name="product_name" required>
            </div>
            <div class="form-group">
                <label for="details">รายละเอียด:</label>
                <textarea class="form-control" id="details" name="details" rows="3" required></textarea>
            </div>
            <div class="form-group">
                <label for="tellnumber">เบอร์โทรศัพท์:</label>
                <input type="text" class="form-control" id="tellnumber" name="tellnumber" required>
            </div>
            <div class="form-group">
                <label for="address">ที่อยู่:</label>
                <input type="text" class="form-control" id="address" name="address" required>
            </div>
            <button type="submit" class="btn btn-primary" onclick="showAlert()">สั่งผลิต</button>
            <a href="index.php" class="btn btn-primary">ย้อนกลับ</a>
        </form>
    </div>
</body>
<script>
    // เพิ่มฟังก์ชันสำหรับกำหนดค่าในช่องข้อมูลชื่อสินค้า
    function setProductionName(product_name) {
        document.getElementById("product_name").value = product_name;
    }

    function showAlert() {
        alert("ยืนยันการสั่งผลิต");
    }
</script>

</html>