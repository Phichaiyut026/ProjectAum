<?php
session_start();
require_once 'database/db_pdo.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // รับข้อมูลจากฟอร์ม
    $product_name = $_POST['product_name'];
    $quantity = $_POST['quantity'];
    $production_date = $_POST['production_date'];

    // ตรวจสอบว่าข้อมูลถูกกรอกครบหรือไม่
    if (!empty($product_name) && !empty($quantity) && !empty($production_date)) {
        try {
            // เตรียมคำสั่ง SQL สำหรับ insert ข้อมูล
            $stmt = $conn->prepare("INSERT INTO production (product_name, quantity, production_date) VALUES (:product_name, :quantity, :production_date)");
            // ผูกค่าพารามิเตอร์
            $stmt->bindParam(':product_name', $product_name);
            $stmt->bindParam(':quantity', $quantity);
            $stmt->bindParam(':production_date', $production_date);
            // ทำการ execute คำสั่ง SQL
            if ($stmt->execute()) {
                // แสดง alert และ redirect ไปหน้า index
                echo "<script>alert('เพิ่มข้อมูลการผลิตเรียบร้อยแล้ว'); window.location.href = 'index.php';</script>";
            } else {
                // แสดงข้อผิดพลาด
                echo "<script>alert('เกิดข้อผิดพลาดในการเพิ่มข้อมูลการผลิต');</script>";
            }
        } catch (PDOException $e) {
            // แสดงข้อผิดพลาด
            echo "<script>alert('เกิดข้อผิดพลาด: " . $e->getMessage() . "');</script>";
        }
    } else {
        // แสดงข้อผิดพลาด
        echo "<script>alert('กรุณากรอกข้อมูลให้ครบทุกช่อง');</script>";
    }
}
?>