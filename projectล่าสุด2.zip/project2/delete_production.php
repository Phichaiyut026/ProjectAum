<?php
session_start();
require_once 'database/db_pdo.php';

if (!isset($_SESSION['admin_login'])) {
    $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
    header('location: login.php');
    exit; // จบการทำงาน
}

// ตรวจสอบว่ามีการส่งค่า id มาหรือไม่
if(isset($_GET['id'])) {
    $production_id = $_GET['id'];

    try {
        // เตรียมคำสั่ง SQL สำหรับลบข้อมูลการผลิต
        $stmt = $conn->prepare("DELETE FROM production WHERE id = :id");
        // ผูกค่าพารามิเตอร์
        $stmt->bindParam(':id', $production_id);
        // ทำการ execute คำสั่ง SQL
        if ($stmt->execute()) {
            $_SESSION['success'] = 'ลบข้อมูลการผลิตเรียบร้อยแล้ว';
        } else {
            $_SESSION['error'] = 'เกิดข้อผิดพลาดในการลบข้อมูลการผลิต';
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = 'เกิดข้อผิดพลาด: ' . $e->getMessage();
    }
} else {
    $_SESSION['error'] = 'ไม่ได้ระบุรหัสการผลิต';
}

// Redirect ไปที่หน้า index.php
header('location: production_tb.php');
?>
