<?php
session_start();
require_once 'database/db_pdo.php';
if (!isset($_SESSION['admin_login'])) {
    $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
    header('location: login.php');
    exit(); // ออกจากสคริปต์หลังจาก redirect
}

// ตรวจสอบว่ามีการส่งค่า ID ของสินค้ามาหรือไม่
if (!isset($_GET['id'])) {
    $_SESSION['error'] = 'ไม่พบรหัสสินค้าที่ต้องการแก้ไข!';
    header('location: product_page.php');
    exit(); // ออกจากสคริปต์หลังจาก redirect
}

$id = $_GET['id'];

// ตรวจสอบว่ามีการส่งข้อมูลแบบ POST หรือไม่
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ดึงข้อมูลที่ต้องการจากฟอร์ม
    $product_name = $_POST['product_name'];
    $details = $_POST['details'];
    $tellnumber = $_POST['tellnumber'];
    $status_name = $_POST['status_name'];
    $address = $_POST['address'];

    // อัปเดตข้อมูลในฐานข้อมูล
    $stmt = $conn->prepare("UPDATE production SET product_name = :product_name, details = :details, tellnumber = :tellnumber, status_name = :status_name, address = :address WHERE id = :id");
    $stmt->bindParam(':product_name', $product_name);
    $stmt->bindParam(':details', $details);
    $stmt->bindParam(':tellnumber', $tellnumber);
    $stmt->bindParam(':status_name', $status_name);
    $stmt->bindParam(':address', $address);
    $stmt->bindParam(':id', $id);

    if ($stmt->execute()) {
        $_SESSION['success'] = 'แก้ไขข้อมูลสินค้าเรียบร้อยแล้ว!';
        header('location: production_tb.php');
        exit(); // ออกจากสคริปต์หลังจาก redirect
    } else {
        $_SESSION['error'] = 'เกิดข้อผิดพลาดในการแก้ไขข้อมูลสินค้า!';
    }
}

// ดึงข้อมูลสินค้าที่ต้องการแก้ไขจากฐานข้อมูล
$stmt = $conn->prepare("SELECT * FROM production WHERE id = :id");
$stmt->bindParam(':id', $id);
$stmt->execute();
$product = $stmt->fetch(PDO::FETCH_ASSOC);

// ตรวจสอบว่ามีข้อมูลสินค้าหรือไม่
if (!$product) {
    $_SESSION['error'] = 'ไม่พบข้อมูลสินค้า!';
    header('location: production_tb.php');
    exit(); // ออกจากสคริปต์หลังจาก redirect
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Production</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            padding: 20px;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
        }

        .form-label {
            font-weight: bold;
        }

        .form-control {
            margin-bottom: 15px;
        }

        .btn-primary,
        .btn-secondary {
            width: 150px;
            margin-right: 10px;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <h1>Edit Production</h1>
        <div class="card-body">
            <form action="edit_production.php?id=<?php echo $id; ?>" method="post">
                <div class="mb-3">
                    <label for="product_name" class="form-label">Product Name</label>
                    <input type="text" class="form-control" id="product_name" name="product_name" value="<?php echo $product['product_name']; ?>" required>
                </div>
                <div class="mb-3">
                    <label for="details" class="form-label">Details</label>
                    <textarea class="form-control" id="details" name="details" rows="3"><?php echo $product['details']; ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="tellnumber" class="form-label">Telephone Number</label>
                    <input type="tel" class="form-control" id="tellnumber" name="tellnumber" value="<?php echo $product['tellnumber']; ?>" required>
                </div>
                <div class="mb-3">
                    <label for="status_name" class="form-label">Status</label>
                    <select class="form-control" id="status_name" name="status_name" required>
                        <option value="รับออเดอร์" <?php if ($product['status_name'] == 'รับออเดอร์') echo 'selected'; ?>>รับออเดอร์</option>
                        <option value="ออกแบบแพ็คเกจ" <?php if ($product['status_name'] == 'ออกแบบแพ็คเกจ') echo 'selected'; ?>>ออกแบบแพ็คเกจ</option>
                        <option value="รอแพ็คเกจ" <?php if ($product['status_name'] == 'รอแพ็คเกจ') echo 'selected'; ?>>รอแพ็คเกจ</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="address" class="form-label">Address</label>
                    <input type="text" class="form-control" id="address" name="address" value="<?php echo $product['address']; ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Save Changes</button>
                <a href="production_tb.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</body>

</html>